<?php
declare(strict_types=1);

/*
 * Copy this file to api/config.php.
 * Local XAMPP defaults are shown below. Replace these with your cPanel
 * database details after creating the database and database user.
 */
define('DB_HOST', getenv('FIGHTCLUB_DB_HOST') ?: '127.0.0.1');
define('DB_NAME', getenv('FIGHTCLUB_DB_NAME') ?: 'fightclubsa');
define('DB_USER', getenv('FIGHTCLUB_DB_USER') ?: 'root');
define('DB_PASS', getenv('FIGHTCLUB_DB_PASS') ?: '');

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
